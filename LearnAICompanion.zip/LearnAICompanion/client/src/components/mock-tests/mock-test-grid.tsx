import { useQuery } from "@tanstack/react-query";
import { MockTest, EXAM_CATEGORIES } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Clock, Plus } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { UploadMockTestDialog } from "./upload-mock-test-dialog";

export function MockTestGrid() {
  const { data: tests, isLoading } = useQuery<MockTest[]>({
    queryKey: ["/api/mock-tests"],
  });
  const { user } = useAuth();

  if (isLoading) {
    return <div>Loading mock tests...</div>;
  }

  const renderCategoryContent = (category: string) => {
    const filteredTests = tests?.filter((t) => t.category === category);

    if (!filteredTests?.length) {
      return (
        <Card className="bg-muted">
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground">No mock tests available yet</p>
            {user?.isAdmin && (
              <UploadMockTestDialog defaultCategory={category} />
            )}
          </CardContent>
        </Card>
      );
    }

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTests.map((test) => (
          <Card key={test.id}>
            <CardHeader>
              <CardTitle>{test.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground line-clamp-2 mb-4">
                {test.description}
              </p>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="h-4 w-4" />
                {test.duration} minutes
              </div>
              <Button className="w-full mt-4">
                Start Test
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };

  return (
    <div>
      {user?.isAdmin && (
        <div className="mb-6 flex justify-end">
          <UploadMockTestDialog />
        </div>
      )}
      <Tabs defaultValue={EXAM_CATEGORIES[0]}>
        <TabsList className="flex flex-wrap">
          {EXAM_CATEGORIES.map((category) => (
            <TabsTrigger key={category} value={category}>
              {category}
            </TabsTrigger>
          ))}
        </TabsList>

        {EXAM_CATEGORIES.map((category) => (
          <TabsContent key={category} value={category}>
            {renderCategoryContent(category)}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
