import { useQuery } from "@tanstack/react-query";
import { Resource, EDUCATION_LEVELS, EDUCATION_STREAMS } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { UploadResourceDialog } from "./upload-resource-dialog";

export function ResourceGrid() {
  const { data: resources, isLoading } = useQuery<Resource[]>({
    queryKey: ["/api/resources"],
  });
  const { user } = useAuth();

  if (isLoading) {
    return <div>Loading resources...</div>;
  }

  const renderStreamContent = (level: string, stream?: string) => {
    const filteredResources = resources
      ?.filter((r) => r.educationLevel === level && (!stream || r.stream === stream));

    if (!filteredResources?.length) {
      return (
        <Card className="bg-muted">
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground">No materials uploaded yet</p>
            {user && (
              <UploadResourceDialog />
            )}
          </CardContent>
        </Card>
      );
    }

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredResources.map((resource) => (
          <Card key={resource.id}>
            <CardHeader>
              <CardTitle>{resource.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground line-clamp-3">
                {resource.content}
              </p>
              {resource.fileUrl && (
                <Button variant="link" className="mt-2" asChild>
                  <a href={resource.fileUrl} target="_blank" rel="noopener noreferrer">
                    View PDF
                  </a>
                </Button>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };

  return (
    <div>
      {user && (
        <div className="mb-6 flex justify-end">
          <UploadResourceDialog />
        </div>
      )}
      <Tabs defaultValue={EDUCATION_LEVELS[0]}>
        <TabsList>
          {EDUCATION_LEVELS.map((level) => (
            <TabsTrigger key={level} value={level}>
              {level.charAt(0).toUpperCase() + level.slice(1)}
            </TabsTrigger>
          ))}
        </TabsList>

        {EDUCATION_LEVELS.map((level) => (
          <TabsContent key={level} value={level}>
            {(level === "undergraduate" || level === "postgraduate") ? (
              <Tabs defaultValue={EDUCATION_STREAMS[level][0]}>
                <TabsList>
                  {EDUCATION_STREAMS[level].map((stream) => (
                    <TabsTrigger key={stream} value={stream}>
                      {stream}
                    </TabsTrigger>
                  ))}
                </TabsList>

                {EDUCATION_STREAMS[level].map((stream) => (
                  <TabsContent key={stream} value={stream}>
                    {renderStreamContent(level, stream)}
                  </TabsContent>
                ))}
              </Tabs>
            ) : (
              renderStreamContent(level)
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}