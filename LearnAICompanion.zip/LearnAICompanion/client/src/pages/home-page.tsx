import { useAuth } from "@/hooks/use-auth";
import { SiteHeader } from "@/components/layout/site-header";
import { ChatInterface } from "@/components/chat/chat-interface";
import { ResourceGrid } from "@/components/resources/resource-grid";
import { MockTestGrid } from "@/components/mock-tests/mock-test-grid";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function HomePage() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      <main className="container mx-auto px-4 py-6">
        <Tabs defaultValue="chat" className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="chat">AI Chat</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
            <TabsTrigger value="mock-tests">Mock Tests</TabsTrigger>
          </TabsList>

          <TabsContent value="chat" className="mt-6">
            <div className="max-w-4xl mx-auto">
              {user && (
                <ChatInterface
                  queryCount={user.queryCount}
                  hasSubscription={user.subscriptionActive}
                />
              )}
            </div>
          </TabsContent>

          <TabsContent value="resources" className="mt-6">
            <ResourceGrid />
          </TabsContent>

          <TabsContent value="mock-tests" className="mt-6">
            <MockTestGrid />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}