import OpenAI from "openai";

let openai: OpenAI | null = null;

// Initialize OpenAI client if API key is available
if (process.env.OPENAI_API_KEY) {
  openai = new OpenAI({ 
    apiKey: process.env.OPENAI_API_KEY
  });
}

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024
const CHAT_MODEL = "gpt-4o";

// Educational context system prompt
const EDUCATION_SYSTEM_PROMPT = `You are an educational AI tutor, tasked with helping students learn and understand various subjects.
Your responses should be:
- Clear and concise
- Accurate and well-explained
- Appropriate for the student's education level
- Encouraging and supportive
- Focused on building understanding rather than just providing answers

When responding to questions:
1. First identify the subject area and difficulty level
2. Break down complex concepts into simpler parts
3. Use examples where appropriate
4. Encourage critical thinking
5. Provide additional resources or practice suggestions when relevant`;

export { openai };

export async function generateEducationalResponse(
  message: string,
  educationLevel?: string
): Promise<{ message: string; tokens: number }> {
  if (!openai) {
    return {
      message: "AI chat is currently unavailable. Please try again once the system is fully configured.",
      tokens: 0
    };
  }

  try {
    const levelContext = educationLevel 
      ? `The student is at ${educationLevel} education level.` 
      : "";

    const response = await openai.chat.completions.create({
      model: CHAT_MODEL,
      messages: [
        { 
          role: "system", 
          content: `${EDUCATION_SYSTEM_PROMPT}\n${levelContext}`
        },
        { 
          role: "user", 
          content: message 
        }
      ],
      temperature: 0.7,
      max_tokens: 1000,
    });

    return {
      message: response.choices[0].message.content || "I apologize, but I couldn't generate a response.",
      tokens: response.usage?.total_tokens || 0
    };
  } catch (error) {
    console.error("OpenAI API Error:", error);
    throw new Error("Failed to generate educational response. Please try again later.");
  }
}

export async function validateResourceContent(
  title: string,
  content: string
): Promise<{ isAppropriate: boolean; feedback: string }> {
  if (!openai) {
    return {
      isAppropriate: false,
      feedback: "AI content validation is currently unavailable. Please try again once the system is fully configured."
    };
  }
  try {
    const response = await openai.chat.completions.create({
      model: CHAT_MODEL,
      messages: [
        {
          role: "system",
          content: "You are a content moderator for an educational platform. Review the submitted content for appropriateness, educational value, and accuracy."
        },
        {
          role: "user",
          content: `Please review this educational resource:
Title: ${title}
Content: ${content}

Respond with JSON containing:
- isAppropriate: boolean (true if content is appropriate and educational)
- feedback: string (reason for decision or improvement suggestions)`
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      isAppropriate: result.isAppropriate ?? false,
      feedback: result.feedback ?? "Content could not be validated"
    };
  } catch (error) {
    console.error("OpenAI Content Validation Error:", error);
    throw new Error("Failed to validate resource content. Please try again later.");
  }
}

export async function suggestImprovements(
  content: string,
  educationLevel: string
): Promise<string> {
  if (!openai) {
    return "AI improvement suggestions are currently unavailable. Please try again once the system is fully configured.";
  }
  try {
    const response = await openai.chat.completions.create({
      model: CHAT_MODEL,
      messages: [
        {
          role: "system",
          content: "You are an educational content improvement specialist. Suggest ways to enhance the educational value and clarity of the content."
        },
        {
          role: "user",
          content: `Please suggest improvements for this ${educationLevel} level educational content:\n\n${content}`
        }
      ],
      temperature: 0.7
    });

    return response.choices[0].message.content || "No improvements suggested.";
  } catch (error) {
    console.error("OpenAI Improvement Suggestions Error:", error);
    throw new Error("Failed to generate improvement suggestions. Please try again later.");
  }
}

export async function categorizeQuestion(
  question: string
): Promise<{ subject: string; difficulty: string }> {
  if (!openai) {
    return { subject: "Unknown", difficulty: "Unknown" };
  }
  try {
    const response = await openai.chat.completions.create({
      model: CHAT_MODEL,
      messages: [
        {
          role: "system",
          content: "Analyze the educational question and categorize it by subject area and difficulty level. Respond with JSON."
        },
        {
          role: "user",
          content: question
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      subject: result.subject || "General",
      difficulty: result.difficulty || "Intermediate"
    };
  } catch (error) {
    console.error("OpenAI Question Categorization Error:", error);
    throw new Error("Failed to categorize question. Please try again later.");
  }
}