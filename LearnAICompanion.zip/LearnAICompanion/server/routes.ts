import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { openai, generateEducationalResponse } from "./openai";
import { insertResourceSchema, insertMockTestSchema } from "@shared/schema";
import { z } from "zod";

function ensureAuthenticated(req: Express.Request, res: Express.Response, next: Express.NextFunction) {
  if (!req.isAuthenticated()) {
    return res.status(401).send("Unauthorized");
  }
  next();
}

function ensureAdmin(req: Express.Request, res: Express.Response, next: Express.NextFunction) {
  if (!req.isAuthenticated() || !req.user.isAdmin) {
    return res.status(403).send("Forbidden");
  }
  next();
}

export function registerRoutes(app: Express): Server {
  setupAuth(app);

  // Chat endpoints
  app.post("/api/chat", ensureAuthenticated, async (req, res) => {
    const user = req.user!;

    if (!user.subscriptionActive && user.queryCount >= 30) {
      return res.status(402).send("Free trial expired");
    }

    try {
      if (!openai) {
        return res.status(503).json({
          message: "Chat service is currently unavailable. Please try again later.",
          queryCount: user.queryCount,
        });
      }

      const response = await generateEducationalResponse(req.body.message);
      await storage.updateUserQueryCount(user.id);

      res.json({
        message: response.message,
        queryCount: user.queryCount + 1,
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Resource endpoints
  app.get("/api/resources", async (req, res) => {
    const resources = await storage.getResources(true);
    res.json(resources);
  });

  app.post("/api/resources", ensureAuthenticated, async (req, res) => {
    try {
      const data = insertResourceSchema.parse(req.body);
      const resource = await storage.createResource({
        ...data,
        authorId: req.user!.id,
      });
      res.status(201).json(resource);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json(error.issues);
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  });

  // Admin resource endpoints
  app.get("/api/admin/resources", ensureAdmin, async (req, res) => {
    const resources = await storage.getResources();
    res.json(resources);
  });

  app.post("/api/admin/resources/:id/approve", ensureAdmin, async (req, res) => {
    try {
      const resource = await storage.approveResource(parseInt(req.params.id));
      res.json(resource);
    } catch (error) {
      res.status(404).json({ error: error.message });
    }
  });

  // Add this after the existing admin resource endpoints
  app.get("/api/admin/stats", ensureAdmin, async (req, res) => {
    try {
      const [
        users,
        resources,
        tests
      ] = await Promise.all([
        storage.getUsers(),
        storage.getResources(),
        storage.getMockTests()
      ]);

      const stats = {
        totalUsers: users?.length || 0,
        activeSubscriptions: users?.filter(u => u.subscriptionActive).length || 0,
        pendingResources: resources?.filter(r => !r.approved).length || 0,
        totalMockTests: tests?.length || 0,
      };

      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Mock test endpoints
  app.get("/api/mock-tests", async (req, res) => {
    const tests = await storage.getMockTests(true);
    res.json(tests);
  });

  app.get("/api/mock-tests/:id", async (req, res) => {
    const test = await storage.getMockTest(parseInt(req.params.id));
    if (!test) {
      return res.status(404).json({ error: "Mock test not found" });
    }
    res.json(test);
  });

  app.post("/api/mock-tests", ensureAdmin, async (req, res) => {
    try {
      const data = insertMockTestSchema.parse(req.body);
      const test = await storage.createMockTest({
        ...data,
        authorId: req.user!.id,
      });
      res.status(201).json(test);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json(error.issues);
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  });

  app.post("/api/mock-tests/:id/publish", ensureAdmin, async (req, res) => {
    try {
      const test = await storage.publishMockTest(parseInt(req.params.id));
      res.json(test);
    } catch (error) {
      res.status(404).json({ error: error.message });
    }
  });

  app.post("/api/subscribe", ensureAuthenticated, async (req, res) => {
    try {
      const user = await storage.updateUserSubscription(req.user!.id, true);
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}