import { users, resources, mockTests, type User, type Resource, type InsertUser, type InsertResource } from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";
import { type MockTest, type InsertMockTest } from "@shared/schema";


const PostgresSessionStore = connectPg(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserBySocialId(provider: string, id: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserQueryCount(userId: number): Promise<User>;
  updateUserSubscription(userId: number, active: boolean): Promise<User>;

  getResources(approved?: boolean): Promise<Resource[]>;
  getResource(id: number): Promise<Resource | undefined>;
  createResource(resource: InsertResource & { authorId: number }): Promise<Resource>;
  approveResource(id: number): Promise<Resource>;

  getMockTests(published?: boolean): Promise<MockTest[]>;
  getMockTest(id: number): Promise<MockTest | undefined>;
  createMockTest(test: InsertMockTest & { authorId: number }): Promise<MockTest>;
  publishMockTest(id: number): Promise<MockTest>;

  sessionStore: session.Store;
  getUsers(): Promise<User[]>;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async getUserBySocialId(provider: string, socialId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(
      and(
        eq(users.socialProvider, provider),
        eq(users.socialProviderId, socialId)
      )
    );
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserQueryCount(userId: number): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ queryCount: users.queryCount + 1 })
      .where(eq(users.id, userId))
      .returning();
    if (!user) throw new Error("User not found");
    return user;
  }

  async updateUserSubscription(userId: number, active: boolean): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ subscriptionActive: active })
      .where(eq(users.id, userId))
      .returning();
    if (!user) throw new Error("User not found");
    return user;
  }

  async getResources(approved?: boolean): Promise<Resource[]> {
    const query = db.select().from(resources);
    if (approved !== undefined) {
      query.where(eq(resources.approved, approved));
    }
    return await query;
  }

  async getResource(id: number): Promise<Resource | undefined> {
    const [resource] = await db.select().from(resources).where(eq(resources.id, id));
    return resource;
  }

  async createResource(resource: InsertResource & { authorId: number }): Promise<Resource> {
    const [newResource] = await db.insert(resources).values(resource).returning();
    return newResource;
  }

  async approveResource(id: number): Promise<Resource> {
    const [resource] = await db
      .update(resources)
      .set({ approved: true })
      .where(eq(resources.id, id))
      .returning();
    if (!resource) throw new Error("Resource not found");
    return resource;
  }

  async getMockTests(published?: boolean): Promise<MockTest[]> {
    const query = db.select().from(mockTests);
    if (published !== undefined) {
      query.where(eq(mockTests.published, published));
    }
    return await query;
  }

  async getMockTest(id: number): Promise<MockTest | undefined> {
    const [test] = await db.select().from(mockTests).where(eq(mockTests.id, id));
    return test;
  }

  async createMockTest(test: InsertMockTest & { authorId: number }): Promise<MockTest> {
    const [newTest] = await db.insert(mockTests).values(test).returning();
    return newTest;
  }

  async publishMockTest(id: number): Promise<MockTest> {
    const [test] = await db
      .update(mockTests)
      .set({ published: true })
      .where(eq(mockTests.id, id))
      .returning();
    if (!test) throw new Error("Mock test not found");
    return test;
  }
  async getUsers(): Promise<User[]> {
    return await db.select().from(users);
  }
}

export const storage = new DatabaseStorage();