import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password"),  // Optional for social login
  email: text("email").notNull().unique(),
  phone: text("phone").notNull(),
  studyCategory: text("study_category").notNull(),
  socialProviderId: text("social_provider_id"),
  socialProvider: text("social_provider"), // 'google', 'facebook', 'instagram'
  isAdmin: boolean("is_admin").notNull().default(false),
  queryCount: integer("query_count").notNull().default(0),
  subscriptionActive: boolean("subscription_active").notNull().default(false),
});

export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  educationLevel: text("education_level").notNull(),
  stream: text("stream").notNull(),
  fileUrl: text("file_url"),
  approved: boolean("approved").notNull().default(false),
  authorId: integer("author_id").notNull(),
});

export const mockTests = pgTable("mock_tests", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull(), // e.g., 'SBI Clerk', 'UPSC'
  description: text("description").notNull(),
  duration: integer("duration").notNull(), // in minutes
  totalQuestions: integer("total_questions").notNull(),
  authorId: integer("author_id").notNull(),
  published: boolean("published").notNull().default(false),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  phone: true,
  studyCategory: true,
  socialProviderId: true,
  socialProvider: true,
});

export const insertResourceSchema = createInsertSchema(resources).pick({
  title: true,
  content: true,
  educationLevel: true,
  stream: true,
  fileUrl: true,
});

export const insertMockTestSchema = createInsertSchema(mockTests).pick({
  title: true,
  category: true,
  description: true,
  duration: true,
  totalQuestions: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertResource = z.infer<typeof insertResourceSchema>;
export type InsertMockTest = z.infer<typeof insertMockTestSchema>;
export type User = typeof users.$inferSelect;
export type Resource = typeof resources.$inferSelect;
export type MockTest = typeof mockTests.$inferSelect;

export const EDUCATION_LEVELS = [
  "primary",
  "secondary",
  "undergraduate",
  "postgraduate",
] as const;

export const EDUCATION_STREAMS = {
  undergraduate: ["BSc", "BA", "BTech", "BBA", "BCA"],
  postgraduate: ["MSc", "MA", "MTech", "MBA", "MCA"],
} as const;

export const EXAM_CATEGORIES = [
  "Bank",
  "Civil Services",
  "Railways",
  "Defence",
  "Teaching",
  "Engineering",
  "Medical",
] as const;

export const STUDY_CATEGORIES = [
  "High School",
  "College Student",
  "Graduate",
  "Post Graduate",
  "Working Professional",
  "Other",
] as const;